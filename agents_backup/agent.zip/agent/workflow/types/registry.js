"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveWorkflowConfig = resolveWorkflowConfig;
const atendimento_1 = require("./atendimento");
const contabil_1 = require("./contabil");
const fiscal_1 = require("./fiscal");
const pessoal_1 = require("./pessoal");
const parecer_2 = require("../../../utils/parecer");
const configMap = {
    fiscal: fiscal_1.fiscalConfig,
    contabil: contabil_1.contabilConfig,
    atendimento: atendimento_1.atendimentoConfig,
    pessoal: pessoal_1.pessoalConfig
};
function resolveWorkflowConfig(tipoParecer) {
    const key = (0, parecer_2.normalizeParecerType)(tipoParecer) || String(tipoParecer || '').toLowerCase();
    return configMap[key] || fiscal_1.fiscalConfig;
}
