"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildClassificationPrompt = buildClassificationPrompt;
exports.buildScopedClassificationPrompt = buildScopedClassificationPrompt;
exports.buildClassificationContents = buildClassificationContents;
exports.routeAgent = routeAgent;
exports.routeAgentWithAllowList = routeAgentWithAllowList;
exports.getAgentPrompt = getAgentPrompt;
exports.buildExtractionPrompt = buildExtractionPrompt;
exports.buildAgentContents = buildAgentContents;
const prompts_1 = require("../../prompts");
const utils_1 = require("../utils");
function buildClassificationPrompt(referenceContext) {
    return (0, utils_1.withReferences)(prompts_1.CLASSIFICACAO_SYSTEM_PROMPT, referenceContext);
}
function buildScopedClassificationPrompt(referenceContext, options = {}) {
    const { reportLabel, allowedTypes } = options;
    if (!allowedTypes || allowedTypes.length === 0) {
        return buildClassificationPrompt(referenceContext);
    }
    const headerLines = [
        '# ORQUESTRADOR DE CLASSIFICACAO',
        reportLabel ? `Relatorio: ${reportLabel}` : null,
        'Use APENAS os tipos abaixo para este relatorio:',
        ...allowedTypes.map((tipo) => `- ${tipo}`),
        'Se o documento nao se encaixar nesses tipos, retorne tipo "DESCONHECIDO" e explique na observacao.',
        'Esta regra tem prioridade sobre qualquer instrucao abaixo.',
        'Ignore qualquer outra lista de tipos nas instrucoes abaixo.'
    ].filter(Boolean);
    const scopedPrompt = `${headerLines.join('\n')}\n\n${prompts_1.CLASSIFICACAO_SYSTEM_PROMPT}`;
    return (0, utils_1.withReferences)(scopedPrompt, referenceContext);
}
function buildClassificationContents(doc, context) {
    const clienteNome = context?.clientName || 'Não informado';
    const regimeTributario = context?.regimeTributario || 'Não informado';
    const sizeKb = doc.size ? (doc.size / 1024).toFixed(2) : '0.00';
    return [
        {
            role: 'user',
            parts: [
                {
                    text: `# DOCUMENTO PARA CLASSIFICAR\n\n**Cliente:** ${clienteNome}\n**Regime Tributário:** ${regimeTributario}\n**Nome do Arquivo:** ${doc.documentoNome}\n**Tamanho:** ${sizeKb} KB\n\nPor favor, classifique este documento seguindo RIGOROSAMENTE as instruções acima.\nRetorne APENAS o JSON, sem markdown, sem explicações extras.`
                }
            ]
        },
        {
            role: 'user',
            parts: [
                {
                    file_data: {
                        file_uri: doc.fileUri,
                        mime_type: doc.mimeType
                    }
                }
            ]
        }
    ];
}
function routeAgent(tipo) {
    if (!tipo)
        return null;
    if (tipo === 'EXTRATO_BANCARIO' || tipo === 'EXTRATO_CARTAO')
        return 'AGENTE_1';
    if (tipo === 'PGDAS_XML' || tipo === 'PGDAS_PDF' || tipo === 'GUIA_DAS')
        return 'AGENTE_2';
    if (tipo === 'FOLHA_PAGAMENTO')
        return 'AGENTE_3';
    if (tipo === 'PONTO_JORNADA')
        return 'AGENTE_5';
    if (tipo === 'NFE_XML' ||
        tipo === 'NFSE_XML' ||
        tipo === 'NFSE_PDF' ||
        tipo === 'CTE_XML' ||
        tipo === 'RESUMO_ACUMULADOR')
        return 'AGENTE_4';
    return null;
}
function routeAgentWithAllowList(tipo, allowList) {
    if (!allowList || allowList.length === 0) {
        return routeAgent(tipo);
    }
    if (!allowList.includes(tipo))
        return null;
    return routeAgent(tipo);
}
function getAgentPrompt(agent) {
    let prompt = '';
    switch (agent) {
        case 'AGENTE_1':
            prompt = prompts_1.AGENTE_1_SYSTEM_PROMPT;
            break;
        case 'AGENTE_2':
            prompt = prompts_1.AGENTE_2_SYSTEM_PROMPT;
            break;
        case 'AGENTE_3':
            prompt = prompts_1.AGENTE_3_SYSTEM_PROMPT;
            break;
        case 'AGENTE_4':
            prompt = prompts_1.AGENTE_4_SYSTEM_PROMPT;
            break;
        case 'AGENTE_5':
            prompt = prompts_1.AGENTE_5_SYSTEM_PROMPT;
            break;
        case 'AGENTE_5_LITE':
            prompt = prompts_1.AGENTE_5_LITE_SYSTEM_PROMPT;
            break;
        default:
            prompt = prompts_1.AGENTE_1_SYSTEM_PROMPT;
    }
    return prompt.startsWith('=') ? prompt.slice(1) : prompt;
}
function buildExtractionPrompt(agent, referenceContext) {
    return (0, utils_1.withReferences)(getAgentPrompt(agent), referenceContext);
}
function buildAgentContents(classification, context) {
    const clienteNome = context?.clientName || classification.clientName || 'Não informado';
    const cnpj = classification.cnpjDetectado || 'não informado';
    const periodo = classification.periodoDetectado || 'não informado';
    return [
        {
            role: 'user',
            parts: [
                {
                    text: `Cliente: ${clienteNome}\nCNPJ: ${cnpj}\nPeriodo: ${periodo}\n\nExtraia todas as entradas.`
                }
            ]
        },
        {
            role: 'user',
            parts: [
                {
                    file_data: {
                        file_uri: classification.file_uri,
                        mime_type: classification.mime_type
                    }
                }
            ]
        }
    ];
}
