"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.atendimentoConfig = void 0;
const fiscal_1 = require("./fiscal");
exports.atendimentoConfig = {
    ...fiscal_1.fiscalConfig,
    id: 'atendimento',
    systemInstruction: `${fiscal_1.fiscalConfig.systemInstruction} Considere que o parecer é do tipo atendimento.`,
    promptIntro: 'Use OBRIGATORIAMENTE a tool code_execution para fazer os calculos. ' +
        'Use o JSON de entrada (consolidado) e gere o JSON final do parecer de atendimento no formato abaixo. ' +
        'A saida deve ser UM unico objeto seguindo o schema, com os calculos do regime tributario.\n\n'
};
