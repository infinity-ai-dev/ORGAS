"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contabilConfig = void 0;
const fiscal_1 = require("./fiscal");
exports.contabilConfig = {
    ...fiscal_1.fiscalConfig,
    id: 'contabil',
    systemInstruction: `${fiscal_1.fiscalConfig.systemInstruction} Considere que o parecer e do tipo contabil.`,
    promptIntro: 'Use OBRIGATORIAMENTE a tool code_execution para fazer os calculos. ' +
        'Use o JSON de entrada (consolidado) e gere o JSON final do parecer contabil no formato abaixo. ' +
        'A saida deve ser UM unico objeto seguindo o schema, com os calculos do regime tributario.\n\n'
};
