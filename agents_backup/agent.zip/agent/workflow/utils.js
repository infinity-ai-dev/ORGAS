"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withReferences = withReferences;
function withReferences(basePrompt, referenceContext) {
    if (!referenceContext)
        return basePrompt;
    return `${basePrompt}\n\n# Referências (seguir rigorosamente)\n${referenceContext}`;
}
