"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.callGemini = callGemini;
async function callGemini(prompt, systemInstruction, config, logTask) {
    logTask("gemini_chamada_iniciada", `model=${config.model}`);
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(config.model)}:generateContent?key=${encodeURIComponent(config.apiKey)}`;
    const body = {
        systemInstruction: { parts: [{ text: systemInstruction }] },
        contents: [
            {
                role: "user",
                parts: [{ text: prompt }],
            },
        ],
        generationConfig: {
            temperature: config.temperature,
            maxOutputTokens: config.maxOutputTokens,
        },
    };
    const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
    });
    if (!res.ok) {
        const errText = await res.text();
        logTask("gemini_chamada_erro", `status=${res.status} body=${errText}`);
        throw new Error(`Gemini error ${res.status}: ${errText}`);
    }
    const data = await res.json();
    const parts = data === null || data === void 0 ? void 0 : data.candidates?.[0]?.content?.parts;
    if (!Array.isArray(parts)) {
        const finishReason = data === null || data === void 0 ? void 0 : data.candidates?.[0]?.finishReason;
        const blockReason = data === null || data === void 0 ? void 0 : data.promptFeedback?.blockReason;
        logTask("gemini_resposta_sem_texto", `finish=${finishReason || "n/a"} block=${blockReason || "n/a"}`);
        const rawSnippet = safeJsonSnippet(data);
        if (rawSnippet) {
            logTask("gemini_resposta_raw", rawSnippet);
        }
        throw new Error("Gemini response sem conteúdo de texto");
    }
    const text = parts.map((p) => p.text || "").join("");
    logTask("gemini_chamada_sucesso", `chars=${text.length}`);
    return { text, raw: data };
}

function safeJsonSnippet(value, limit = 2000) {
    try {
        const raw = JSON.stringify(value);
        if (!raw)
            return "";
        return raw.length > limit ? `${raw.slice(0, limit)}...` : raw;
    }
    catch (_error) {
        return "[unserializable]";
    }
}
