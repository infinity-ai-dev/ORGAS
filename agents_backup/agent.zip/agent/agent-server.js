"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const fs_1 = __importDefault(require("fs"));
const agent_router_1 = require("./agent-router");
dotenv_1.default.config();
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3000;
app.set('trust proxy', 1);
app.use((0, cors_1.default)({
    origin: process.env.FRONTEND_URL || 'https://app.orgahold.com',
    credentials: true
}));
app.use(express_1.default.json({ limit: '50mb' }));
app.use(express_1.default.urlencoded({ limit: '50mb', extended: true }));
function readEnvOrFile(name) {
    const direct = (process.env[name] || '').trim();
    if (direct)
        return direct;
    const fileVar = `${name}_FILE`;
    const filePath = (process.env[fileVar] || '').trim();
    if (!filePath)
        return '';
    try {
        return fs_1.default.readFileSync(filePath, 'utf8').trim();
    }
    catch (_a) {
        return '';
    }
}
function getAuthToken(req) {
    const authHeader = req.headers.authorization || '';
    if (authHeader.startsWith('Bearer ')) {
        return authHeader.replace('Bearer ', '').trim();
    }
    return '';
}
function requireWebhookToken(req, res, next) {
    const token = getAuthToken(req);
    const webhookToken = readEnvOrFile('WEBHOOK_TOKEN');
    if (!webhookToken) {
        return res.status(500).json({ success: false, error: 'WEBHOOK_TOKEN não configurado' });
    }
    if (!token) {
        return res.status(401).json({ success: false, error: 'Token de autorização não fornecido' });
    }
    if (token !== webhookToken) {
        return res.status(403).json({ success: false, error: 'Token de autorização inválido' });
    }
    return next();
}
app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        service: 'orgas-ai-agent',
        timestamp: new Date().toISOString()
    });
});
app.use((0, agent_router_1.createAgentRouter)(requireWebhookToken));
app.listen(PORT, () => {
    console.log('🤖 Agent server rodando na porta', PORT);
    console.log('🔐 Agent endpoints: /agente-ia e /api/agente-ia');
});
