"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAgentRouter = createAgentRouter;
const express_1 = require("express");
const agent_service_1 = require("./agent-service");
function createAgentRouter(authMiddleware) {
    const router = (0, express_1.Router)();
    const middlewares = authMiddleware ? [authMiddleware] : [];
    router.post(["/agente-ia", "/api/agente-ia"], ...middlewares, async (req, res) => {
        const logTask = (task, detail) => {
            const prefix = detail ? ` - ${detail}` : "";
            console.log(`🧠 [AGENTE-IA] ${task}${prefix}`);
        };
        try {
            logTask("request_recebida", `ip=${req.ip}`);
            const result = await (0, agent_service_1.runAgent)(req.body || {}, logTask);
            res.json({ success: true, ...result });
        }
        catch (error) {
            logTask("erro", (error === null || error === void 0 ? void 0 : error.message) || String(error));
            res.status(500).json({
                success: false,
                error: (error === null || error === void 0 ? void 0 : error.message) || "Erro interno",
            });
        }
    });
    return router;
}
