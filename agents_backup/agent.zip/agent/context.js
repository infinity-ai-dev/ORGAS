"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadReferences = loadReferences;
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
async function loadReferences(dir, maxChars, logTask, allowList) {
    logTask('carregar_referencias', `dir=${dir}`);
    let entries = [];
    try {
        const dirents = await promises_1.default.readdir(dir, { withFileTypes: true });
        let mdFiles = dirents
            .filter((d) => d.isFile() && d.name.toLowerCase().endsWith('.md'))
            .map((d) => d.name)
            .sort();
        if (allowList && allowList.length > 0) {
            const normalized = new Set(allowList.map((n) => n.trim()).filter(Boolean));
            mdFiles = mdFiles.filter((name) => normalized.has(name));
            logTask('referencias_filtradas', mdFiles.join(',') || 'nenhuma');
        }
        for (const name of mdFiles) {
            const fullPath = path_1.default.join(dir, name);
            const content = await promises_1.default.readFile(fullPath, 'utf8');
            entries.push({ name, content });
        }
    }
    catch (error) {
        logTask('carregar_referencias_erro', String(error));
    }
    const mergedRaw = entries
        .map((f) => `# ${f.name}\n\n${f.content}`)
        .join('\n\n');
    const merged = mergedRaw.length > maxChars ? mergedRaw.slice(0, maxChars) : mergedRaw;
    return { dir, files: entries, merged };
}
