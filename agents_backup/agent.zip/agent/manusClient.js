"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runManusTask = void 0;
const doneStatuses = new Set(['completed', 'done', 'finished', 'success', 'succeeded']);
const failStatuses = new Set(['failed', 'error', 'cancelled', 'canceled']);
const extractOutputText = (task) => {
    const output = Array.isArray(task?.output) ? task.output : [];
    const texts = [];
    for (const msg of output) {
        if (String(msg?.role || '').toLowerCase() !== 'assistant')
            continue;
        const contents = Array.isArray(msg?.content) ? msg.content : [];
        for (const part of contents) {
            if (part?.type === 'output_text' && part?.text) {
                texts.push(String(part.text));
            }
        }
    }
    return texts.join('\n\n').trim();
};
const parseTaskId = (obj) => obj?.task_id ||
    obj?.taskId ||
    obj?.id ||
    obj?.data?.id ||
    obj?.data?.task_id;
const parseStatus = (obj) => String(obj?.status || obj?.state || obj?.phase || obj?.task_status || '').toLowerCase();
const runManusTask = async (config, payload) => {
    const { tasksUrl, headers, pollIntervalMs, maxWaitMs, timeoutMs, logTask } = config;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
        logTask?.('manus_payload', `bytes=${Buffer.byteLength(JSON.stringify(payload), 'utf8')} attachments=${Array.isArray(payload.attachments) ? payload.attachments.length : 0}`);
        let createRes = null;
        let createRaw = '';
        try {
            createRes = await fetch(tasksUrl, {
                method: 'POST',
                headers,
                body: JSON.stringify(payload),
                signal: controller.signal
            });
            createRaw = await createRes.text();
        }
        catch (error) {
            const detail = error?.cause ? String(error.cause) : String(error);
            const code = error?.code || error?.cause?.code;
            logTask?.('manus_task_fetch_error', `${detail}${code ? ` code=${code}` : ''}`);
            return null;
        }
        if (!createRes)
            return null;
        if (!createRes.ok) {
            logTask?.('manus_http_error', `${createRes.status} ${createRaw.slice(0, 200)}`);
            return null;
        }
        let createParsed = null;
        try {
            createParsed = JSON.parse(createRaw);
        }
        catch {
            createParsed = null;
        }
        const taskId = parseTaskId(createParsed);
        logTask?.('manus_task_created', `status=${createRes.status} taskId=${taskId || 'na'}`);
        if (!taskId) {
            return { task: createParsed, outputText: extractOutputText(createParsed) };
        }
        const taskUrl = `${new URL(tasksUrl).origin}/v1/tasks/${taskId}`;
        const start = Date.now();
        let lastStatus = '';
        while (Date.now() - start < maxWaitMs) {
            await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
            let pollRes = null;
            let pollRaw = '';
            try {
                pollRes = await fetch(taskUrl, { headers });
                pollRaw = await pollRes.text();
            }
            catch (error) {
                const detail = error?.cause ? String(error.cause) : String(error);
                const code = error?.code || error?.cause?.code;
                logTask?.('manus_task_fetch_error', `${detail}${code ? ` code=${code}` : ''}`);
                logTask?.('manus_poll_error', 'sem_resposta_poll');
                continue;
            }
            if (!pollRes)
                continue;
            let pollParsed = null;
            try {
                pollParsed = JSON.parse(pollRaw);
            }
            catch {
                pollParsed = null;
            }
            if (!pollRes.ok || !pollParsed) {
                logTask?.('manus_poll_error', `${pollRes.status} ${pollRaw.slice(0, 200)}`);
                continue;
            }
            const status = parseStatus(pollParsed);
            if (status && status !== lastStatus) {
                lastStatus = status;
                logTask?.('manus_poll_status', status);
            }
            if (failStatuses.has(status)) {
                logTask?.('manus_failed', status);
                return null;
            }
            if (doneStatuses.has(status)) {
                return { task: pollParsed, outputText: extractOutputText(pollParsed) };
            }
            if (pollParsed?.output) {
                const outputText = extractOutputText(pollParsed);
                if (outputText) {
                    return { task: pollParsed, outputText };
                }
            }
        }
        logTask?.('manus_timeout', 'timeout');
        return null;
    }
    finally {
        clearTimeout(timeout);
    }
};
exports.runManusTask = runManusTask;
