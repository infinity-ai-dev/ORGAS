"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAgentRouter = createAgentRouter;
const express_2 = require("express");
const agentService_2 = require("./agentService");
function createAgentRouter(authMiddleware) {
    const router = (0, express_2.Router)();
    const middlewares = authMiddleware ? [authMiddleware] : [];
    router.post(['/agente-ia', '/api/agente-ia'], ...middlewares, async (req, res) => {
        const logTask = (task, detail) => {
            const prefix = detail ? ` - ${detail}` : '';
            console.log(`🧠 [AGENTE-IA] ${task}${prefix}`);
        };
        try {
            logTask('request_recebida', `ip=${req.ip}`);
            const result = await (0, agentService_2.runAgent)(req.body || {}, logTask);
            res.json({ success: true, ...result });
        }
        catch (error) {
            logTask('erro', error?.message || String(error));
            res.status(500).json({
                success: false,
                error: error?.message || 'Erro interno'
            });
        }
    });
    return router;
}
