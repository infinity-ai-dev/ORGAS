# PITCH DECK - IDENTIFICAÇÃO DE VIDROS POR IA
## Template para Apresentação (10 Slides)

---

## SLIDE 1: CAPA

### Layout:
```
[Logo da empresa - centralizado]

IDENTIFICAÇÃO DE VIDROS AUTOMOTIVOS POR IA

[Tagline]
"O Shazam para vidros automotivos"

[Seu nome]
Fundador & CEO

[Contato]
email@empresa.com | +55 11 xxxxx-xxxx
```

### Elementos visuais:
- Logo profissional
- Foto de um vidro sendo identificado por smartphone
- Cores: Azul confiança + Verde tecnologia

---

## SLIDE 2: O PROBLEMA

### Título: "Um Mercado de R$ 3 Bilhões com um Grande Problema"

### Conteúdo:
```
3 MILHÕES
de substituições de vidros/ano no Brasil

20-40 MINUTOS
tempo médio para identificar cada vidro

15-20%
taxa de erro na identificação

R$ 300-800
custo médio de cada erro
```

### Elementos visuais:
- Ícones para cada estatística
- Foto de vidraceiro frustrado consultando catálogo
- Gráfico mostrando tempo desperdiçado

### Narrativa verbal:
"Entrevistamos 15 vidraceiros. 87% relatam que a identificação de vidros é seu maior problema operacional diário."

---

## SLIDE 3: A SOLUÇÃO

### Título: "Identificação Instantânea por IA"

### Layout em 3 passos:
```
1️⃣ TIRE UMA FOTO          2️⃣ IA IDENTIFICA          3️⃣ RECEBA O RESULTADO
   [imagem: smartphone]      [imagem: cérebro AI]      [imagem: tela com info]
   
   Qualquer smartphone       Menos de 10 segundos      Modelo exato + onde comprar
```

### Tecnologia (box inferior):
```
🧠 3 Modelos de IA em Paralelo:
├─ OCR para códigos DOT
├─ Detecção de logos e sensores  
└─ Classificação de modelo
```

### Diferencial destacado:
> "Funciona mesmo SEM VIN ou documentação"

---

## SLIDE 4: DEMO / PRODUTO

### Título: "Como Funciona na Prática"

### Layout:
- Screenshot do app mobile (3-4 telas)
  - Tela 1: Camera captura
  - Tela 2: Processando...
  - Tela 3: Resultado com 95% confiança
  - Tela 4: Links para fornecedores

### OU (se não tiver app pronto):
- Video demo de 30 segundos embedded
- QR code para testar beta

### Texto de apoio:
```
✓ Interface intuitiva
✓ Resultado em <10 segundos
✓ Confiabilidade de 85%+
✓ Integração com distribuidores
```

---

## SLIDE 5: MERCADO

### Título: "Oportunidade de R$ 600 Milhões"

### Gráfico de funil (TAM/SAM/SOM):
```
┌──────────────────────────────────┐
│ TAM: R$ 3 bilhões                │ ← Mercado total BR
│ (50.000 vidraceiros)             │
└──────────────────────────────────┘
         ↓
   ┌────────────────────────┐
   │ SAM: R$ 600 milhões    │ ← Endereçável (20k com smartphone)
   │ (20.000 vidraceiros)   │
   └────────────────────────┘
            ↓
      ┌──────────────┐
      │ SOM: R$ 700k │ ← Meta 3 anos (1.000 clientes)
      └──────────────┘
```

### Crescimento do mercado:
```
📈 Aftermarket automotivo crescendo 5.8% ao ano
📈 Mercado global: USD 28 bi até 2030
📈 Digitalização acelerando pós-pandemia
```

---

## SLIDE 6: MODELO DE NEGÓCIO

### Título: "Receita Recorrente com Alta Margem"

### Tabela de pricing:
```
┌─────────────┬──────────┬────────────────┐
│ Plano       │ Preço    │ Features       │
├─────────────┼──────────┼────────────────┤
│ Grátis      │ R$ 0     │ 5 consultas    │
│ Pay-per-use │ R$ 8     │ Por consulta   │
│ Pro         │ R$ 59/mês│ Ilimitado      │
│ Enterprise  │ R$ 299   │ API + multi    │
└─────────────┴──────────┴────────────────┘
```

### Economia de unidade:
```
CAC: R$ 150  →  LTV: R$ 1.416  →  LTV/CAC: 9.4x ✅

Margem: >80% (software puro)
```

### Upsells:
- API para integração: R$ 299/mês
- White-label: R$ 999/mês
- Treinamento: R$ 500

---

## SLIDE 7: TRAÇÃO

### Título: "Validação de Mercado Concluída"

### Timeline visual:
```
✅ MÊS 1-2: Pesquisa de Mercado
   → 15 vidraceiros entrevistados
   → 87% confirmam problema crítico
   
✅ MÊS 3-6: MVP Manual (Wizard of Oz)
   → 45 identificações
   → 89% de precisão
   → NPS: 52
   
🚀 MÊS 7-12: Protótipo IA
   → Dataset: 180 vidros
   → Precisão: 85%+
   → 3 clientes beta testando
```

### Carta de intenção:
> "📄 Distribuidor regional com 500 vidraceiros na rede demonstrou interesse em parceria"

---

## SLIDE 8: CONCORRÊNCIA

### Título: "Oceano Azul - Zero Concorrentes Diretos"

### Matriz de competição:
```
┌─────────────────┬───────────┬─────────────┬──────────┐
│                 │ VIN Decoders│ Genéricos│ NÓS      │
├─────────────────┼───────────┼─────────────┼──────────┤
│ Sem VIN         │ ❌        │ ✅          │ ✅       │
│ Especialização  │ ⚠️        │ ❌          │ ✅       │
│ Velocidade      │ ✅        │ ⚠️          │ ✅       │
│ Precisão vidros │ ✅        │ ❌          │ ✅       │
│ Preço           │ $$        │ $           │ $$       │
└─────────────────┴───────────┴─────────────┴──────────┘
```

### Nossos diferenciais:
```
🏆 Primeiro e único focado 100% em vidros
🏆 Dataset proprietário (anos para replicar)
🏆 Network effects: mais dados → melhor modelo
🏆 Parcerias estratégicas já iniciadas
```

---

## SLIDE 9: EQUIPE & ROADMAP

### Coluna esquerda - Equipe:
```
👤 [Seu Nome] - Fundador & CEO
   [Seu background relevante]
   [LinkedIn icon]

👥 Advisors:
   • [Nome] - Especialista IA
   • [Nome] - Executivo automotivo
   • [Nome] - Ex-founder exitado
```

### Coluna direita - Roadmap:
```
Q1 2025: MVP + 100 beta users
         → R$ 5k MRR

Q2-Q3: Escala Brasil + 500 clientes
       → R$ 30k MRR

Q4: Expansão LATAM + 1.500 clientes
    → R$ 90k MRR

2026: Outras peças + Seguradoras
      → R$ 150k MRR
```

---

## SLIDE 10: O PEDIDO (THE ASK)

### Título: "Buscamos R$ 200-300k para Escalar"

### Uso de recursos (gráfico de pizza):
```
50% Tecnologia
    └─ Dev full-time
    └─ Infraestrutura
    
30% Marketing/Vendas
    └─ CAC de 200 clientes
    └─ Campanhas digitais
    
20% Operacional
    └─ Dataset expansion
    └─ Parcerias
```

### Milestones com funding:
```
✓ Mês 3:  500 vidros no dataset
✓ Mês 6:  200 clientes pagantes (R$ 12k MRR)
✓ Mês 12: 500 clientes (R$ 30k MRR)
✓ Mês 18: Break-even
```

### Call to action:
```
[Grande e centralizado]

VAMOS CONVERSAR?

[Email]
[Telefone]
[Agendar reunião - link Calendly]
```

---

## SLIDE BÔNUS: APÊNDICE (se necessário)

### Dados financeiros detalhados:
- Projeção 5 anos
- Unit economics
- Breakdown de custos

### Dados de validação:
- Transcrições de entrevistas
- Screenshots de feedbacks
- Métricas detalhadas

---

## DICAS DE APRESENTAÇÃO

### Timing por slide:
1. Capa: 15 seg
2. Problema: 45 seg
3. Solução: 45 seg
4. Demo: 30 seg
5. Mercado: 30 seg
6. Modelo: 30 seg
7. Tração: 30 seg
8. Concorrência: 30 seg
9. Equipe/Roadmap: 30 seg
10. Ask: 30 seg

**Total: ~5 minutos** (deixa tempo para perguntas)

### Storytelling:
1. **Hook**: Comece com história real de um vidraceiro
2. **Problema**: Mostre o CUSTO da dor (tempo + dinheiro)
3. **Solução**: Demo ao vivo se possível
4. **Prova**: Dados reais de validação
5. **Visão**: Onde isso pode chegar (outras peças, seguradoras)
6. **Pedido**: Seja específico e confiante

### O que NÃO fazer:
❌ Ler slides
❌ Texto demais
❌ Falar muito de tecnologia (foque no valor)
❌ Comparar com concorrentes fracos
❌ Ser vago no "ask"

### O que FAZER:
✅ Contar histórias
✅ Usar visuals fortes
✅ Demonstrar paixão
✅ Ter dados concretos
✅ Mostrar que entende o mercado

---

## VERSÕES DO DECK

### Versão Curta (5 slides - 3 min):
1. Problema + Solução
2. Demo
3. Mercado + Modelo
4. Tração
5. Ask

### Versão Média (10 slides - 5 min):
- [Esta versão]

### Versão Longa (15 slides - 10 min):
- Adicionar: Detalhes técnicos, Go-to-market, Financials

---

## FERRAMENTAS PARA CRIAR

### Gratuitas:
- Canva (templates prontos)
- Google Slides
- Pitch.com

### Pagas:
- PowerPoint
- Keynote (Mac)
- Beautiful.ai

### Recomendação:
**Canva** - Templates profissionais, fácil de usar, exporta PDF

---

## CHECKLIST PRÉ-APRESENTAÇÃO

- [ ] Deck revisado (sem typos)
- [ ] Testado em voz alta (cronometrado)
- [ ] Backup em 3 formatos (PDF, PPTX, link)
- [ ] Demo funcional (se for mostrar)
- [ ] Versão impressa (para reunião)
- [ ] Follow-up preparado (email template)
- [ ] Perguntas difíceis antecipadas
- [ ] Energia alta! ☕

---

**ÚLTIMA ATUALIZAÇÃO:** ___/___/_______
**VERSÃO:** 1.0
