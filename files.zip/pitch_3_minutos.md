# PITCH DE 3 MINUTOS - IDENTIFICAÇÃO DE VIDROS AUTOMOTIVOS POR IA

## 1. GANCHO (10 segundos)
"E se você pudesse identificar qualquer vidro automotivo em 10 segundos apenas tirando uma foto?"

## 2. PROBLEMA (30 segundos)
### O mercado de reposição de vidros automotivos movimenta R$ 3 bilhões por ano no Brasil.

**Mas há um problema crítico:**
- Vidraceiros gastam **20-40 minutos** para identificar cada vidro
- Taxa de erro de **15-20%** = prejuízo + retrabalho + cliente insatisfeito
- Soluções atuais dependem de VIN (nem sempre disponível) ou catálogos manuais extensos
- Vidros usados/importados são **impossíveis** de identificar com métodos tradicionais
- Um erro custa em média **R$ 300-800** (peça errada + mão de obra + tempo)

**Dor validada:** Entrevistamos 15 vidraceiros - 87% relatam este como seu maior problema operacional.

---

## 3. SOLUÇÃO (40 segundos)
### Desenvolvemos a primeira IA especializada em identificação de vidros automotivos.

**Como funciona:**
1. Vidraceiro tira foto do vidro com smartphone
2. Nossa IA identifica em **menos de 10 segundos**
3. Retorna: modelo exato, código DOT, fabricante, onde comprar

**Tecnologia:**
- Combina **3 modelos de IA**: OCR + detecção de objetos + classificação
- Treinada especificamente para desafios de vidros (reflexo, transparência, curvatura)
- Banco de dados proprietário de +1.000 modelos (meta)
- App mobile + integração com distribuidores
- **Funciona mesmo sem VIN ou documentação**

**Diferencial:** Não somos um identificador genérico - somos especializados 100% em vidros automotivos.

---

## 4. POR QUE AGORA? (20 segundos)
### Timing perfeito:
- ✅ Visão computacional amadureceu (YOLOv8, transformers)
- ✅ Smartphones com câmeras de alta qualidade são ubíquos
- ✅ Mercado aftermarket crescendo 5.8% ao ano
- ✅ **ZERO concorrentes diretos** neste nicho específico
- ✅ Pandemia acelerou digitalização de negócios tradicionais

---

## 5. MERCADO (30 segundos)
### **TAM (Total Addressable Market):**
- 50.000+ vidraceiros/oficinas no Brasil
- 3 milhões de substituições de vidros/ano
- Mercado global aftermarket: **USD 28 bilhões** até 2030

### **SAM (Serviceable Available Market):**
- 20.000 vidraceiros com smartphone no Brasil + LATAM
- **R$ 600 milhões/ano** (capturando 20% do TAM)

### **SOM (Serviceable Obtainable Market - 3 anos):**
- 1.000 clientes pagantes
- R$ 59/mês × 12 × 1.000 = **R$ 708k ARR**
- Apenas 0,1% do mercado total (muito conservador)

---

## 6. MODELO DE NEGÓCIO (30 segundos)
### **B2B2C (foco inicial em B2B):**

**Receita Principal:**
- Assinatura mensal: **R$ 59-99/mês** por vidraceiro
- Freemium: 5 consultas grátis → conversão para pago

**Upsells:**
- API para integração: R$ 299/mês
- White-label para distribuidores: R$ 999/mês
- Treinamento e onboarding: R$ 500 one-time

**Economia de Unidade:**
- CAC (Custo de Aquisição): ~R$ 150 (marketing digital + vendas)
- LTV (Lifetime Value): R$ 1.416 (R$ 59 × 24 meses)
- LTV/CAC: **9.4x** (excelente)
- Margem: **>80%** (software puro)

---

## 7. TRAÇÃO (20 segundos)
### **Validação até agora:**
- ✅ MVP 1 concluído: 15 vidraceiros entrevistados, 87% confirmam dor
- ✅ MVP 2 em andamento: 45 identificações manuais, 89% de precisão, NPS = 52
- ✅ Dataset inicial: 180 vidros fotografados e anotados
- ✅ Primeiros 3 clientes beta testando (feedback positivo)
- ✅ Carta de intenção de 1 distribuidor regional (500 vidraceiros na rede)

*[Ajustar conforme seu estágio real]*

---

## 8. CONCORRÊNCIA & DIFERENCIAÇÃO (30 segundos)
### **Concorrentes Indiretos:**

| Solução | Limitação | Nossa Vantagem |
|---------|-----------|----------------|
| VIN Decoders (AutoGlassCRM) | Precisa de VIN acessível | Funciona sem VIN |
| Identificadores genéricos (Foogle) | Sem especialização | 100% focado em vidros |
| Catálogos manuais | Lento (30-40min) | 10 segundos |
| Ligar para fornecedor | Depende de horário comercial | 24/7 |

### **Barreiras de Entrada (aumentam com o tempo):**
1. **Dataset proprietário** - Difícil de replicar (anos de coleta)
2. **Network effects** - Mais usuários → mais dados → melhor modelo
3. **Parcerias** - Relacionamentos com distribuidores/fabricantes
4. **Marca** - Primeira e única solução dedicada a vidros

---

## 9. EQUIPE (20 segundos)
### [Adapte para sua realidade]

**Fundador(a):**
- Background: [Seu background - tech/automotivo/negócios]
- Por que você: [Sua motivação/experiência relevante]

**Advisors/Mentores:**
- [Nome]: Especialista em IA/Computer Vision
- [Nome]: 20 anos no mercado de autopeças
- [Nome]: Ex-executivo de startup que escalou para X milhões

**Contratações planejadas:**
- Desenvolvedor full-stack (com funding)
- Vendedor B2B (após product-market fit)

---

## 10. ROADMAP (30 segundos)
### **Próximos 18 meses:**

**Q1 2025 (Meses 1-3): Validação**
- Finalizar MVP3 com IA funcional
- Alcançar 100 usuários beta
- Validar product-market fit
- Métrica: **R$ 5k MRR**

**Q2-Q3 2025 (Meses 4-9): Escala Nacional**
- Expandir dataset para 1.000+ vidros
- Fechar 3-5 parcerias com distribuidores
- Alcançar 500 clientes pagantes
- Métrica: **R$ 30k MRR**

**Q4 2025 - Q1 2026 (Meses 10-15): Expansão LATAM**
- Lançar no México e Argentina
- Lançar API para integrações B2B
- Alcançar 1.500 clientes
- Métrica: **R$ 90k MRR**

**Q2 2026 (Meses 16-18): Diversificação**
- Expandir para outras peças (faróis, para-choques)
- Parcerias com seguradoras
- Marketplace de peças usado IA
- Métrica: **R$ 150k MRR**

---

## 11. O PEDIDO (THE ASK) (20 segundos)

### **Para Investidores:**
**Buscamos R$ 200-300k em investimento seed para:**
- Contratar 1 desenvolvedor full-time (R$ 10k/mês × 12)
- Expandir dataset para 500 modelos (R$ 30k)
- Marketing e aquisição de clientes (R$ 50k - CAC de 200 clientes)
- Operacional e infraestrutura (R$ 30k)
- **12-15 meses de runway**

**Uso de Recursos:**
- 50% Tecnologia (dev + infra)
- 30% Marketing/Vendas
- 20% Operacional

**Valuation proposto:** R$ 1,5-2M pre-money (10-15% equity)

---

### **Para Aceleradoras:**
**Buscamos:**
- Mentoria em go-to-market B2B
- Network de investidores e potenciais parceiros
- Estruturação de vendas para aftermarket automotivo
- Acesso a pilotos com grandes redes de oficinas

---

### **Para Parceiros Estratégicos:**
**Buscamos distribuidores de vidros interessados em:**
- Pilotar a integração API
- Co-desenvolver features específicas
- Oferecer para sua rede de vidraceiros
- Modelo de revenue share ou licenciamento white-label

---

## 12. FECHAMENTO (10 segundos)
### "Somos o Shazam para vidros automotivos."

**Um mercado de bilhões. Zero concorrentes diretos. Problema validado.**

**Vamos conversar?**

---

## CONTATO
- Email: [seu email]
- WhatsApp: [seu número]
- LinkedIn: [seu perfil]
- Deck completo: [link para deck]

---

## ANEXOS

### Dados de Validação:
- Entrevistas completas: [link]
- Métricas de MVP2: [link]
- Cartas de intenção: [link]

### Projeções Financeiras:
- Modelo financeiro 5 anos: [link para planilha]
- Breakdown de custos: [link]

### Produto:
- Demo em vídeo: [link]
- Screenshots do app: [link]
