# ✅ CHECKLIST COMPLETO DE EXECUÇÃO - 12 SEMANAS

## 📅 CRONOGRAMA GERAL

```
Semanas 1-2:  Validação da Dor
Semanas 3-6:  Wizard of Oz
Semanas 7-12: Protótipo IA
Semana 13+:   Escala
```

---

## 🎯 FASE 1: VALIDAÇÃO DA DOR (Semanas 1-2)

### Semana 1: Preparação + Primeiras Entrevistas

#### Segunda-feira
- [ ] Criar planilha de tracking no Google Sheets
- [ ] Listar 30 vidraceiros no Google Maps (raio de 50km)
- [ ] Preparar script de cold calling
- [ ] Imprimir 20 cópias do roteiro de entrevista

#### Terça-feira
- [ ] Ligar para 15 vidraceiros e agendar visitas
- [ ] Meta: agendar 5-7 visitas para esta semana
- [ ] Preparar material: bloco, caneta, gravador (com permissão)

#### Quarta-feira
- [ ] Visita 1: _____________________ (nome)
  - Horário: _____
  - Endereço: _____
  - Completar roteiro de entrevista
  - Tirar fotos do processo (com permissão)
  
- [ ] Visita 2: _____________________ (nome)
  - [mesmos campos]

#### Quinta-feira
- [ ] Visita 3 e 4
- [ ] Compilar dados das primeiras visitas na planilha

#### Sexta-feira
- [ ] Visita 5
- [ ] Analisar padrões emergentes
- [ ] Ajustar roteiro se necessário

### Semana 2: Completar Entrevistas + Decisão

#### Segunda-feira
- [ ] Ligar para mais 10 vidraceiros
- [ ] Agendar 5-8 visitas para esta semana

#### Terça a Quinta
- [ ] Executar 10 entrevistas restantes
- [ ] Compilar todos os dados na planilha

#### Sexta-feira - DIA DE DECISÃO
- [ ] Analisar todos os dados coletados
- [ ] Calcular métricas:
  - % que confirmam dificuldade: _____%
  - Tempo médio de identificação: _____ min
  - Taxa de erro média: _____%
  - Custo médio de erro: R$ _____
  - % dispostos a pagar: _____%
  - Valor médio que pagariam: R$ _____

#### ⚡ DECISÃO GO/NO-GO:

**✅ GO para Fase 2 SE:**
- ≥70% confirmam dificuldade significativa ✓ □
- Tempo médio >15 minutos ✓ □
- Taxa de erro >10% ✓ □
- ≥50% demonstram interesse em pagar ✓ □

**❌ NO-GO SE:**
- Menos de 50% veem como problema real
- Soluções atuais são satisfatórias
- Ninguém demonstra disposição a pagar

---

## 🧙 FASE 2: WIZARD OF OZ (Semanas 3-6)

### Semana 3: Setup

#### Segunda-feira
- [ ] Criar conta no Carrd.co ($19/ano)
- [ ] Escolher template simples e clean
- [ ] Escrever copy da landing page

#### Terça-feira
- [ ] Configurar WhatsApp Business
  - Mensagem automática de boas-vindas
  - Horário de atendimento
  - Respostas rápidas salvas
- [ ] Criar Google Sheet para tracking:
  - Colunas: Data | Cliente | Foto | Resposta | Tempo | Feedback | NPS

#### Quarta-feira
- [ ] Finalizar landing page
- [ ] Comprar domínio (opcional): identificadordevidros.com.br
- [ ] Testar fluxo completo: LP → WhatsApp → você responde

#### Quinta-feira
- [ ] Criar material de divulgação:
  - Post para Instagram/Facebook
  - Mensagem para enviar aos vidraceiros entrevistados
  - Cartão de visitas digital

#### Sexta-feira
- [ ] Enviar mensagem para os 15 vidraceiros entrevistados
- [ ] Postar em grupos de Facebook de vidraceiros/mecânicos
- [ ] Configurar Google Analytics na LP

### Semanas 4-6: Operação Manual

#### Rotina Diária (Segunda a Sexta)

**Manhã (9h-12h):**
- [ ] Checar WhatsApp
- [ ] Responder requisições recebidas
- [ ] Meta: identificar cada vidro em <30min

**Processo para cada requisição:**
1. [ ] Receber foto via WhatsApp
2. [ ] Salvar foto com nome: data_cliente_numero.jpg
3. [ ] Identificar usando:
   - Catálogos online
   - Google Lens
   - Contatos (distribuidores)
   - Código DOT visível
4. [ ] Responder cliente em formato padrão:
   ```
   ✅ Identificado!
   
   Modelo: [nome completo]
   Código DOT: [se visível]
   Fabricante: [marca]
   Ano: [estimado]
   
   Onde comprar:
   - Fornecedor A: R$ XXX
   - Fornecedor B: R$ XXX
   
   Confiança: 95%
   
   Essa resposta foi útil? (1-10)
   ```
5. [ ] Registrar na planilha

**Tarde (14h-17h):**
- [ ] Continuar respondendo
- [ ] Anotar dificuldades encontradas
- [ ] Estudar casos que não conseguiu identificar

**Noite:**
- [ ] Compilar métricas do dia
- [ ] Responder feedbacks

#### Fim de Semana
- [ ] Analisar dados da semana
- [ ] Ajustar processo se necessário
- [ ] Preparar materiais de estudo para casos difíceis

### Semana 6 - Sexta: Análise de Resultados

- [ ] Calcular métricas finais:
  - Total de requisições: _____
  - Precisão (% acertos): _____%
  - Tempo médio de resposta: _____ min
  - NPS (Net Promoter Score): _____
  - % casos impossíveis: _____%
  - % dispostos a pagar: _____%

#### ⚡ DECISÃO GO/NO-GO PARA FASE 3:

**✅ GO para Fase 3 SE:**
- Precisão ≥80% ✓ □
- NPS >40 ✓ □
- ≥30% dizem que pagariam ✓ □
- Tempo de resposta viável (<30min) ✓ □
- Você conseguiu identificar >80% dos casos ✓ □

---

## 🤖 FASE 3: PROTÓTIPO IA (Semanas 7-12)

### Semana 7: Coleta de Dataset

#### Segunda-feira
- [ ] Listar 5-10 desmanches na região
- [ ] Ligar e agendar visitas
- [ ] Preparar equipamento:
  - Smartphone com boa câmera
  - Bateria extra
  - Tripé (opcional)
  - Fita métrica
  - Caderno para anotações

#### Terça a Sexta
- [ ] Visitar desmanches
- [ ] Meta: fotografar 10-15 modelos por dia
- [ ] Para cada vidro:
  - 10-15 fotos (ângulos diferentes)
  - Foto do código DOT
  - Foto de logos/marcas
  - Foto de sensores (se houver)
  - Medir dimensões aproximadas
  - Anotar: modelo, fabricante, ano, características

### Semana 8: Anotação de Dataset

#### Segunda a Quarta
- [ ] Organizar fotos em pastas:
  ```
  dataset/
    ├── gol_g5_frontal/
    │   ├── img001.jpg
    │   ├── img002.jpg
    │   └── ...
    ├── civic_2010_frontal/
    └── ...
  ```
- [ ] Criar arquivo CSV com metadados:
  ```
  filename, modelo, fabricante, ano, tipo, dot_code, tem_sensor
  ```

#### Quinta-Sexta
- [ ] Anotar bounding boxes para YOLO (se for treinar detecção)
- [ ] Pode usar ferramenta: LabelImg ou Roboflow
- [ ] Meta: anotar pelo menos 50% do dataset

### Semana 9: Desenvolvimento ou Contratação

#### Opção A - Fazer Você Mesmo

**Segunda-feira**
- [ ] Setup ambiente de desenvolvimento:
  - Instalar Python 3.10+
  - Criar virtual environment
  - Instalar dependências: PyTorch, Ultralytics, FastAPI

**Terça-Quarta**
- [ ] Implementar OCR básico:
  - Instalar EasyOCR
  - Testar em 20 imagens
  - Ajustar pré-processamento

**Quinta-Sexta**
- [ ] Implementar classificação:
  - Usar transfer learning (ResNet18 pré-treinado)
  - Treinar em seu dataset
  - Avaliar precisão inicial

#### Opção B - Contratar Freelancer

**Segunda-feira**
- [ ] Criar job description detalhada
- [ ] Listar requisitos técnicos
- [ ] Definir orçamento: R$ 3.000-8.000
- [ ] Postar em:
  - Workana
  - 99Freelas
  - GetNinjas
  - Grupos de freelancers

**Terça-Quarta**
- [ ] Revisar propostas
- [ ] Entrevistar 3-5 candidatos
- [ ] Checar portfólios e referências

**Quinta-Sexta**
- [ ] Selecionar freelancer
- [ ] Assinar contrato
- [ ] Fazer primeira reunião de alinhamento
- [ ] Transferir dataset e requisitos

### Semana 10-11: Desenvolvimento

#### Se fazendo você mesmo:
**Checklist de desenvolvimento:**
- [ ] Módulo 1: Pré-processamento de imagens
- [ ] Módulo 2: OCR para código DOT
- [ ] Módulo 3: Detecção de logos (YOLO)
- [ ] Módulo 4: Classificação de modelo
- [ ] Módulo 5: API REST (FastAPI)
- [ ] Módulo 6: Integração dos 3 modelos
- [ ] Módulo 7: Matching com banco de dados
- [ ] Testes unitários básicos

#### Se contratou freelancer:
- [ ] Reuniões de checkpoint (2x por semana)
- [ ] Revisar código em desenvolvimento
- [ ] Testar incrementalmente
- [ ] Dar feedback contínuo

### Semana 12: Testes e Lançamento Beta

#### Segunda-Terça: Testes
- [ ] Preparar dataset de teste (20% separado)
- [ ] Testar precisão:
  - Precisão global: _____%
  - Precisão por categoria: _____
  - Taxa de falsos positivos: _____%
  - Tempo de resposta: _____ seg

#### Quarta: Ajustes
- [ ] Corrigir bugs críticos
- [ ] Melhorar casos com baixa confiança
- [ ] Otimizar velocidade

#### Quinta: Preparar Lançamento
- [ ] Criar landing page atualizada
- [ ] Preparar onboarding para beta users
- [ ] Criar materiais de suporte (FAQs, tutoriais)

#### Sexta: Lançamento Beta
- [ ] Convidar 20 usuários do Wizard of Oz
- [ ] Oferecer 1 mês grátis
- [ ] Enviar email com instruções
- [ ] Setup sistema de feedback

---

## 📊 MÉTRICAS A RASTREAR CONTINUAMENTE

### Métricas de Produto
- [ ] Precisão da IA: _____%
- [ ] Tempo médio de resposta: _____ seg
- [ ] Uptime do sistema: _____%
- [ ] Taxa de erro: _____%

### Métricas de Negócio
- [ ] Usuários ativos: _____
- [ ] Consultas/dia: _____
- [ ] Taxa de conversão free→paid: _____%
- [ ] MRR (Monthly Recurring Revenue): R$ _____
- [ ] Churn rate: _____%
- [ ] NPS: _____

### Métricas de Crescimento
- [ ] CAC (Custo de Aquisição): R$ _____
- [ ] LTV (Lifetime Value): R$ _____
- [ ] LTV/CAC ratio: _____
- [ ] Taxa de crescimento semanal: _____%

---

## ⚡ DECISÕES GO/NO-GO RESUMIDAS

### Fim da Semana 2:
**IR PARA FASE 2?**
- [ ] ≥70% confirmam dificuldade → ✅ SIM / ❌ NÃO
- [ ] Tempo médio >15min → ✅ SIM / ❌ NÃO
- [ ] ≥50% pagariam → ✅ SIM / ❌ NÃO

### Fim da Semana 6:
**IR PARA FASE 3?**
- [ ] Precisão ≥80% → ✅ SIM / ❌ NÃO
- [ ] NPS >40 → ✅ SIM / ❌ NÃO
- [ ] ≥30% pagariam → ✅ SIM / ❌ NÃO

### Fim da Semana 12:
**ESCALAR?**
- [ ] Precisão IA ≥85% → ✅ SIM / ❌ NÃO
- [ ] ≥5 clientes pagantes → ✅ SIM / ❌ NÃO
- [ ] NPS >50 → ✅ SIM / ❌ NÃO

---

## 💰 BUDGET TOTAL

### Fase 1 (Semanas 1-2):
- Gasolina/transporte: R$ 300
- Cafés/almoços: R$ 200
- **Total: R$ 500**

### Fase 2 (Semanas 3-6):
- Landing page (Carrd): R$ 100
- Domínio: R$ 40
- Ads iniciais (opcional): R$ 300
- **Total: R$ 440**

### Fase 3 (Semanas 7-12):
- Visitas a desmanches: R$ 400
- Freelancer (se contratar): R$ 3.000-8.000
- Servidor/hospedagem: R$ 200/mês = R$ 400
- Ferramentas: R$ 200
- **Total: R$ 4.000-9.000**

### **INVESTIMENTO TOTAL: R$ 5.000-10.000**

---

## 📞 CONTATOS IMPORTANTES

### Fornecedores de Vidros (para validação):
1. _____________________ - Tel: _____
2. _____________________ - Tel: _____
3. _____________________ - Tel: _____

### Desenvolvedores (se contratar):
1. _____________________ - Portfólio: _____
2. _____________________ - Portfólio: _____

### Mentores/Advisors:
1. _____________________ - Área: _____
2. _____________________ - Área: _____

---

## 🎯 PRÓXIMA AÇÃO

**COMEÇAR AGORA:**
- [ ] Marcar no calendário: blocos de 4h para visitas (Semanas 1-2)
- [ ] Preparar primeira lista de 10 vidraceiros
- [ ] Imprimir este checklist
- [ ] **Fazer primeira ligação hoje!**

---

## 🔄 REVISÃO SEMANAL

Todo domingo:
- [ ] Revisar progresso da semana
- [ ] Atualizar métricas
- [ ] Ajustar plano se necessário
- [ ] Preparar próxima semana

---

ÚLTIMA ATUALIZAÇÃO: ___/___/_______
PRÓXIMA REVISÃO: ___/___/_______
