# PLANILHA DE TRACKING - VALIDAÇÃO MVP
## Copie este template para Google Sheets

---

## 📊 ABA 1: VALIDAÇÃO DA DOR (Fase 1)

### Colunas da planilha:

| Data | Vidraceiro | Tamanho | Tempo ID (min) | Taxa Erro (%) | Custo Erro (R$) | Usa Catálogo? | Usa VIN? | Frustração (1-10) | Pagaria? | Valor/mês (R$) | Observações |
|------|-----------|---------|----------------|---------------|-----------------|---------------|----------|-------------------|----------|----------------|-------------|
| 05/01| José Auto | Pequena | 35             | 20            | 400             | Sim           | Às vezes | 8                 | Sim      | 50             | Muito interessado |
| 06/01| Maria Vidros| Média  | 25             | 15            | 300             | Sim           | Não      | 7                 | Talvez   | 30             | Quer testar primeiro |
| 07/01| ...       | ...     | ...            | ...           | ...             | ...           | ...      | ...               | ...      | ...            | ... |

### Fórmulas úteis:

**Tempo médio de identificação:**
```
=AVERAGE(D2:D16)
```

**Taxa de erro média:**
```
=AVERAGE(E2:E16)
```

**% que pagariam:**
```
=COUNTIF(J2:J16,"Sim")/COUNTA(J2:J16)*100
```

**Valor médio que pagariam:**
```
=AVERAGE(K2:K16)
```

### Análise automática (células de resumo):

```
Total entrevistados:     =COUNTA(B2:B16)
Tempo médio ID:          =AVERAGE(D2:D16) & " min"
Taxa erro média:         =AVERAGE(E2:E16) & "%"
% dispostos a pagar:     =COUNTIF(J2:J16,"Sim")/COUNTA(J2:J16)*100 & "%"
Preço médio sugerido:    ="R$ " & AVERAGE(K2:K16)

DECISÃO GO/NO-GO:        =IF(
                           AND(
                             (COUNTIF(I2:I16,">=7")/COUNTA(I2:I16))>=0.7,
                             AVERAGE(D2:D16)>15,
                             AVERAGE(E2:E16)>10,
                             (COUNTIF(J2:J16,"Sim")/COUNTA(J2:J16))>=0.5
                           ),
                           "✅ GO PARA FASE 2",
                           "❌ PARAR E REAVALIAR"
                         )
```

---

## 📊 ABA 2: WIZARD OF OZ (Fase 2)

### Colunas da planilha:

| Data | Cliente | Foto ID | Resposta Dada | Tempo Resp (min) | Correto? | Confiança (%) | NPS (0-10) | Comentário | Pagaria? |
|------|---------|---------|---------------|------------------|----------|---------------|------------|------------|----------|
| 15/01| Cliente A| vid001.jpg| Gol G5 Frontal| 22              | Sim      | 95            | 9          | Muito rápido!| Sim     |
| 15/01| Cliente B| vid002.jpg| Civic 2010   | 18              | Sim      | 90            | 8          | Útil       | Sim     |
| 16/01| Cliente C| vid003.jpg| Não identif. | 45              | N/A      | 0             | 3          | Não funcionou| Não   |
| ...  | ...     | ...     | ...           | ...              | ...      | ...           | ...        | ...        | ...     |

### Fórmulas úteis:

**Precisão geral:**
```
=COUNTIF(F2:F101,"Sim")/COUNTA(F2:F101)*100 & "%"
```

**Tempo médio de resposta:**
```
=AVERAGE(E2:E101) & " min"
```

**NPS Score:**
```
=((COUNTIF(H2:H101,">=9")-COUNTIF(H2:H101,"<=6"))/COUNTA(H2:H101))*100
```
(NPS = % Promotores (9-10) - % Detratores (0-6))

**% casos impossíveis:**
```
=COUNTIF(F2:F101,"N/A")/COUNTA(F2:F101)*100 & "%"
```

**Taxa de conversão:**
```
=COUNTIF(J2:J101,"Sim")/COUNTA(J2:J101)*100 & "%"
```

### Análise automática:

```
Total identificações:    =COUNTA(B2:B101)
Precisão:                =COUNTIF(F2:F101,"Sim")/COUNTA(F2:F101)*100 & "%"
Tempo médio:             =AVERAGE(E2:E101) & " min"
NPS:                     =[fórmula acima]
% Impossíveis:           =COUNTIF(F2:F101,"N/A")/COUNTA(F2:F101)*100 & "%"
% Conversão:             =COUNTIF(J2:J101,"Sim")/COUNTA(J2:J101)*100 & "%"

DECISÃO GO/NO-GO:        =IF(
                           AND(
                             (COUNTIF(F2:F101,"Sim")/COUNTA(F2:F101))>=0.8,
                             [NPS]>40,
                             (COUNTIF(J2:J101,"Sim")/COUNTA(J2:J101))>=0.3,
                             AVERAGE(E2:E101)<30
                           ),
                           "✅ GO PARA FASE 3",
                           "❌ PARAR E REAVALIAR"
                         )
```

---

## 📊 ABA 3: PROTÓTIPO IA (Fase 3)

### Colunas da planilha:

| Data | Cliente | Tipo | Modelo Real | Modelo Previsto | Correto? | Confiança IA (%) | Tempo (seg) | Feedback | Converteu? | Valor Pago (R$) |
|------|---------|------|-------------|-----------------|----------|------------------|-------------|----------|------------|-----------------|
| 10/03| Beta 1  | Frontal| Gol G6    | Gol G6          | Sim      | 92               | 8           | Ótimo    | Sim        | 59              |
| 10/03| Beta 2  | Lateral| Civic 2012| Civic 2010      | Não      | 78               | 9           | Errou    | Não        | 0               |
| 11/03| ...     | ...  | ...         | ...             | ...      | ...              | ...         | ...      | ...        | ...             |

### Métricas de IA:

**Precisão:**
```
=COUNTIF(F2:F51,"Sim")/COUNTA(F2:F51)*100 & "%"
```

**Confiança média:**
```
=AVERAGE(G2:G51) & "%"
```

**Tempo médio:**
```
=AVERAGE(H2:H51) & " segundos"
```

**Taxa de conversão free→paid:**
```
=COUNTIF(J2:J51,"Sim")/COUNTA(J2:J51)*100 & "%"
```

**MRR (Monthly Recurring Revenue):**
```
=SUM(K2:K51) & " (assumindo plano mensal)"
```

### Análise por tipo de vidro:

| Tipo | Precisão | Casos |
|------|----------|-------|
| Frontal | =AVERAGEIF(C:C,"Frontal",G:G) | =COUNTIF(C:C,"Frontal") |
| Lateral | =AVERAGEIF(C:C,"Lateral",G:G) | =COUNTIF(C:C,"Lateral") |
| Traseiro| =AVERAGEIF(C:C,"Traseiro",G:G)| =COUNTIF(C:C,"Traseiro")|

---

## 📊 ABA 4: MÉTRICAS DE CRESCIMENTO (Pós-lançamento)

### Tracking semanal:

| Semana | Novos Users | Total Users | Consultas | Pagantes | MRR (R$) | Churn | CAC (R$) | NPS |
|--------|-------------|-------------|-----------|----------|----------|-------|----------|-----|
| 1      | 20          | 20          | 150       | 2        | 118      | 0%    | 75       | 55  |
| 2      | 35          | 55          | 420       | 8        | 472      | 0%    | 120      | 58  |
| 3      | 28          | 83          | 580       | 15       | 885      | 5%    | 95       | 60  |
| ...    | ...         | ...         | ...       | ...      | ...      | ...   | ...      | ... |

### Fórmulas:

**Total Users acumulado:**
```
=SUM(B$2:B2)
```

**MRR (assumindo R$ 59/mês):**
```
=E2*59
```

**Churn rate (%):**
```
=(E2-E3)/E2*100  [usuários perdidos]
```

**Growth rate semanal:**
```
=(C2-C1)/C1*100 & "%"
```

**LTV (Lifetime Value):**
```
=59*24  [R$ 1.416 - assumindo 24 meses]
```

**LTV/CAC Ratio:**
```
=1416/AVERAGE(H:H)
```

---

## 📊 ABA 5: PROJEÇÕES FINANCEIRAS

### Projeção 12 meses:

| Mês | Novos Clientes | Total Clientes | MRR (R$) | Custos (R$) | Lucro (R$) | Acumulado (R$) |
|-----|----------------|----------------|----------|-------------|------------|----------------|
| 1   | 10             | 10             | 590      | 5.000       | -4.410     | -4.410         |
| 2   | 15             | 25             | 1.475    | 3.000       | -1.525     | -5.935         |
| 3   | 20             | 45             | 2.655    | 3.000       | -345       | -6.280         |
| 4   | 25             | 70             | 4.130    | 3.000       | 1.130      | -5.150         |
| 5   | 30             | 100            | 5.900    | 3.500       | 2.400      | -2.750         |
| 6   | 35             | 135            | 7.965    | 3.500       | 4.465      | 1.715          |
| ... | ...            | ...            | ...      | ...         | ...        | ...            |
| 12  | 70             | 500            | 29.500   | 8.000       | 21.500     | +50.000        |

### Breakdown de custos:

| Item | Mês 1-3 | Mês 4-6 | Mês 7-12 |
|------|---------|---------|----------|
| Desenvolvedor | 10.000 | 10.000 | 10.000 |
| Servidor/Infra| 500    | 800     | 1.200  |
| Marketing     | 2.000  | 4.000   | 8.000  |
| Ferramentas   | 200    | 300     | 500    |
| **TOTAL**     | 12.700 | 15.100  | 19.700 |

---

## 📊 ABA 6: DASHBOARD EXECUTIVO

### KPIs principais (atualizar semanalmente):

```
┌─────────────────────────────────────┐
│  MÉTRICAS DE PRODUTO                │
├─────────────────────────────────────┤
│ Precisão da IA:        87%          │
│ Tempo médio resposta:  9 seg        │
│ Uptime:                99.2%        │
│ Taxa de erro:          13%          │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  MÉTRICAS DE NEGÓCIO                │
├─────────────────────────────────────┤
│ Usuários ativos:       250          │
│ Consultas/dia:         180          │
│ Taxa conversão:        32%          │
│ MRR:                   R$ 15.870    │
│ Churn rate:            8%           │
│ NPS:                   62           │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  MÉTRICAS DE CRESCIMENTO            │
├─────────────────────────────────────┤
│ CAC:                   R$ 185       │
│ LTV:                   R$ 1.416     │
│ LTV/CAC:               7.6x         │
│ Growth rate (WoW):     22%          │
│ Burn rate:             R$ 12k/mês   │
│ Runway:                8 meses      │
└─────────────────────────────────────┘
```

### Gráficos recomendados:

1. **MRR ao longo do tempo** (linha)
2. **Precisão da IA por tipo de vidro** (barras)
3. **Funil de conversão** (funil)
4. **NPS ao longo do tempo** (linha)
5. **Custos vs Receita** (barras empilhadas)

---

## 🎯 METAS E MILESTONES

### Checkpoints críticos:

| Milestone | Meta | Data Target | Status |
|-----------|------|-------------|--------|
| MVP 1 - Validação Dor | 70%+ confirmam problema | 15/01/2025 | ⏳ |
| MVP 2 - Wizard of Oz | 80%+ precisão manual | 15/02/2025 | ⏳ |
| MVP 3 - IA Funcional | 85%+ precisão | 30/03/2025 | ⏳ |
| 10 clientes pagantes | R$ 590 MRR | 30/04/2025 | ⏳ |
| 50 clientes | R$ 2.950 MRR | 30/06/2025 | ⏳ |
| 100 clientes | R$ 5.900 MRR | 30/08/2025 | ⏳ |
| Break-even | Lucro > 0 | 31/12/2025 | ⏳ |

**Legenda:** ⏳ Pendente | ✅ Concluído | ❌ Atrasado | 🔄 Em andamento

---

## 💡 COMO USAR ESTA PLANILHA

### Setup inicial:
1. Copiar para Google Sheets
2. Ajustar datas para seu timeline
3. Configurar fórmulas automáticas
4. Criar gráficos dinâmicos

### Rotina de atualização:
- **Diária:** Adicionar novos dados de requisições
- **Semanal:** Calcular métricas agregadas
- **Mensal:** Revisar projeções e ajustar metas

### Compartilhamento:
- Investidores: Enviar Aba 6 (Dashboard) semanalmente
- Equipe: Acesso completo
- Advisors: Abas 4-6 (crescimento e financeiro)

---

**ÚLTIMA ATUALIZAÇÃO:** ___/___/_______
**RESPONSÁVEL:** _________________
